interface ProductCardProps {
  name: string;
  description?: string | null;
  price: number;
  imageUrl?: string | null;
  whatsappNumber?: string;
  whatsappMessage?: string;
  hidePrice?: boolean;
  hideWhatsApp?: boolean;
}

function formatPrice(price: number): string {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    minimumFractionDigits: 0,
  }).format(price);
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
}

const gradients = [
  "from-nude to-champagne",
  "from-beige to-nude-dark",
  "from-champagne-dark to-nude",
  "from-cream-dark to-beige-dark",
  "from-nude to-beige",
  "from-champagne to-nude-dark",
];

function getGradient(name: string): string {
  const idx =
    name.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0) %
    gradients.length;
  return gradients[idx];
}

export default function ProductCard({
  name,
  description,
  price,
  imageUrl,
  whatsappNumber = "+5491155551234",
  whatsappMessage = "Hola! Quisiera consultar por el producto",
  hidePrice = false,
  hideWhatsApp = false,
}: ProductCardProps) {
  const encodedMessage = encodeURIComponent(
    `${whatsappMessage} ${name}`
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}?text=${encodedMessage}`;

  return (
    <div className="group bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 overflow-hidden">
      <div className="aspect-square relative overflow-hidden">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className={`w-full h-full bg-gradient-to-br ${getGradient(name)} flex items-center justify-center`}>
            <span className="text-4xl font-playfair font-bold text-white/80">
              {getInitials(name)}
            </span>
          </div>
        )}
      </div>
      <div className="p-5 pb-14 relative">
        <h3 className="font-playfair text-lg font-semibold text-warm-brown-dark mb-1 line-clamp-1">
          {name}
        </h3>
        {description && (
          <p className="font-lato text-sm text-warm-gray mb-3 line-clamp-2 leading-relaxed">
            {description}
          </p>
        )}
        {!hidePrice && (
          <p className="font-lato text-xl font-bold text-champagne-dark mb-4">
            {formatPrice(price)}
          </p>
        )}
        {!hideWhatsApp && (
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="absolute bottom-3 right-3 w-9 h-9 bg-[#25D366] hover:bg-[#1da851] text-white rounded-full flex items-center justify-center transition-all duration-300 hover:shadow-md hover:scale-110"
            title="Consultar por WhatsApp"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
          </a>
        )}
      </div>
    </div>
  );
}
